package com.universidad.servicio;

import java.util.List;

public interface Servicios {
    String imprimirPosicion(String posicion);
    Integer cantidadActual();
    List<String> imprimirListado();
}
